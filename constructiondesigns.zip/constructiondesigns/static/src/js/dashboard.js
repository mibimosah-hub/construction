/** @odoo-module **/

import {
    Component,
    onWillStart,
    onMounted,
    useRef,
    useState,
} from "@odoo/owl";

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";


export class ConstructionDashboard extends Component {

    static template = "constructiondesigns.ConstructionDashboard";

    setup() {

        // ORM service
        this.orm = useService("orm");

        // Action service
        this.actionService = useService("action");

        // Pie chart reference
        this.deadlineChartRef = useRef("deadlineChart");

        // Dashboard state
        this.state = useState({

            total_projects: 0,
            total_customers: 0,
            total_employees: 0,

            total_material_amount: 0,
            total_material_no: 0,
            total_material_quantity: 0,
            total_low_stock: 0,

            overdue_count: 0,
            approaching_count: 0,
            safe_count: 0,

            loading: true,
            error: false,

        });

        // Load dashboard data
        onWillStart(async () => {
            await this.loadDashboardData();
        });

        // Draw chart after component is mounted
        onMounted(() => {
            this.drawDeadlineChart();
        });

    }


    // ============================================
    // SAFE DATA LOADING
    // ============================================

    async loadValue(callback, defaultValue = 0) {

        try {

            return await callback();

        } catch (error) {

            console.error(
                "Dashboard data loading error:",
                error
            );

            return defaultValue;

        }

    }


    // ============================================
    // LOAD DASHBOARD DATA
    // ============================================

    async loadDashboardData() {

        try {

            // Total Projects
            this.state.total_projects = await this.loadValue(
                () => this.orm.searchCount(
                    "construction.project",
                    []
                )
            );


            // Total Customers
            this.state.total_customers = await this.loadValue(
                () => this.orm.searchCount(
                    "customer.add",
                    []
                )
            );


            // Total Employees
            this.state.total_employees = await this.loadValue(
                () => this.orm.searchCount(
                    "construction.employee",
                    []
                )
            );


            // Total Material Amount
            this.state.total_material_amount = await this.loadValue(
                () => this.orm.call(
                    "construction.stock",
                    "get_all_material_amount",
                    []
                )
            );


            // Total Number of Materials
            this.state.total_material_no = await this.loadValue(
                () => this.orm.searchCount(
                    "construction.stock",
                    []
                )
            );


            // Total Material Quantity
            this.state.total_material_quantity = await this.loadValue(
                () => this.orm.call(
                    "construction.stock",
                    "get_total_material_quantity",
                    []
                )
            );

        console.log(
            "Total Material Quantity:",
            this.state.total_material_quantity
        );

            //low stock material
            this.state.total_low_stock = await this.loadValue(
            () => this.orm.call(
                "construction.stock",
                "get_low_stock_count",
                []
            )
        );


            // WBS Deadline Chart
            const chartData = await this.loadValue(
                () => this.orm.call(
                    "wbs.phase",
                    "get_deadline_chart_data",
                    []
                ),
                []
            );

            const validChartData = Array.isArray(chartData)
                ? chartData
                : [];


            // Overdue
            this.state.overdue_count =
                validChartData.find(
                    item => item.label === "Overdue"
                )?.count || 0;


            // Approaching
            this.state.approaching_count =
                validChartData.find(
                    item => item.label === "Approaching"
                )?.count || 0;


            // Safe
            this.state.safe_count =
                validChartData.find(
                    item => item.label === "Safe"
                )?.count || 0;


        } catch (error) {

            console.error(
                "Dashboard loading error:",
                error
            );

            this.state.error = true;

        } finally {

            this.state.loading = false;

            requestAnimationFrame(() => {
                this.drawDeadlineChart();
            });

        }

    }


    // ============================================
    // PROJECT CARD CLICK
    // ============================================

    openProjectForm() {

        this.actionService.doAction({

            type: "ir.actions.act_window",

            name: "Projects",

            res_model: "construction.project",

            views: [
                [false, "list"],
                [false, "form"],
            ],

            target: "current",

        });

    }


    // ============================================
    // CUSTOMER CARD CLICK
    // ============================================

    openCustomerForm() {

        this.actionService.doAction({

            type: "ir.actions.act_window",

            name: "Customers",

            res_model: "customer.add",

            views: [
                [false, "list"],
                [false, "form"],
            ],

            target: "current",

        });

    }


    // ============================================
    // EMPLOYEE CARD CLICK
    // ============================================

    openEmployeeForm() {

        this.actionService.doAction({

            type: "ir.actions.act_window",

            name: "Employees",

            res_model: "construction.employee",

            views: [
                [false, "list"],
                [false, "form"],
            ],

            target: "current",

        });

    }


    // ============================================
    // MATERIAL CARD CLICK
    // ============================================

    openMaterialForm() {

        this.actionService.doAction({

            type: "ir.actions.act_window",

            name: "Materials",

            res_model: "construction.stock",

            views: [
                [false, "list"],
                [false, "form"],
            ],

            target: "current",

        });
        openLowStockMaterials()
        {
                        this.actionService.doAction({
                            type: "ir.actions.act_window",
                            name: "Low Stock Materials",
                            res_model: "construction.stock",
                            views: [[false, "list"], [false, "form"]],
                            domain: [
                                ["status", "=", "low"]
                            ],
                            target: "current",
                        });
}

    }


    // ============================================
    // OPEN LOW STOCK MATERIALS
    // ============================================

    openLowStockMaterials() {

        this.actionService.doAction({

            type: "ir.actions.act_window",

            name: "Low Stock Materials",

            res_model: "construction.stock",

            views: [
                [false, "list"],
                [false, "form"],
            ],

            domain: [
                ["status", "=", "low"]
            ],

            target: "current",

        });

    }


    // ============================================
    // OPEN ALL WBS DEADLINE RECORDS
    // ============================================

    openDeadlineForm() {

        this.actionService.doAction(
            "constructiondesigns.action_wbs_phase_deadline"
        );

    }


    // ============================================
    // OPEN WBS RECORDS BY STATUS
    // ============================================

    openWbsRecords(deadline_status) {

        const actions = {

            overdue: "constructiondesigns.action_wbs_overdue",

            approaching: "constructiondesigns.action_wbs_approaching",

            safe: "constructiondesigns.action_wbs_safe",

        };

        const action = actions[deadline_status];

        if (action) {

            this.actionService.doAction(action);

        } else {

            console.error(
                "Invalid deadline status:",
                deadline_status
            );

        }

    }


    // ============================================
    // PIE CHART CLICK DETECTION
    // ============================================

    onDeadlineChartClick(event) {

        const canvas = this.deadlineChartRef.el;

        if (!canvas) {
            return;
        }

        const rect = canvas.getBoundingClientRect();

        if (!rect.width || !rect.height) {
            return;
        }

        const x =
            (event.clientX - rect.left) *
            (canvas.width / rect.width);

        const y =
            (event.clientY - rect.top) *
            (canvas.height / rect.height);

        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;

        const dx = x - centerX;
        const dy = y - centerY;

        const distance = Math.sqrt(
            dx * dx + dy * dy
        );

        const radius =
            Math.min(canvas.width, canvas.height) * 0.35;

        if (distance > radius) {
            return;
        }

        const total =
            this.state.overdue_count +
            this.state.approaching_count +
            this.state.safe_count;

        if (total === 0) {
            return;
        }

        let angle = Math.atan2(dy, dx);

        const startAngle = -Math.PI / 2;

        if (angle < startAngle) {
            angle += 2 * Math.PI;
        }

        const categories = [

            {
                status: "overdue",
                count: this.state.overdue_count,
            },

            {
                status: "approaching",
                count: this.state.approaching_count,
            },

            {
                status: "safe",
                count: this.state.safe_count,
            },

        ];

        let currentAngle = startAngle;

        for (const category of categories) {

            if (category.count <= 0) {
                continue;
            }

            const sliceAngle =
                (category.count / total) * 2 * Math.PI;

            const endAngle =
                currentAngle + sliceAngle;

            if (
                angle >= currentAngle &&
                angle < endAngle
            ) {

                this.openWbsRecords(category.status);

                return;

            }

            currentAngle = endAngle;

        }

    }


    // ============================================
    // DRAW WBS DEADLINE PIE CHART
    // ============================================

    drawDeadlineChart() {

        const canvas = this.deadlineChartRef.el;

        if (!canvas) {
            return;
        }

        const ctx = canvas.getContext("2d");

        if (!ctx) {
            return;
        }

        ctx.clearRect(
            0,
            0,
            canvas.width,
            canvas.height
        );

        const categories = [

            {
                label: "Overdue",
                count: this.state.overdue_count,
                color: "#ef4444",
            },

            {
                label: "Approaching",
                count: this.state.approaching_count,
                color: "#f59e0b",
            },

            {
                label: "Safe",
                count: this.state.safe_count,
                color: "#22c55e",
            },

        ];

        const total = categories.reduce(
            (sum, item) => sum + item.count,
            0
        );

        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;

        const radius =
            Math.min(canvas.width, canvas.height) * 0.35;


        // No records
        if (total === 0) {

            ctx.fillStyle = "#64748b";
            ctx.font = "16px Arial";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            ctx.fillText(
                "No deadline records",
                centerX,
                centerY
            );

            return;

        }


        // Draw pie slices
        let startAngle = -Math.PI / 2;

        categories.forEach((item) => {

            if (item.count <= 0) {
                return;
            }

            const sliceAngle =
                (item.count / total) * 2 * Math.PI;

            const endAngle =
                startAngle + sliceAngle;

            ctx.beginPath();

            ctx.moveTo(centerX, centerY);

            ctx.arc(
                centerX,
                centerY,
                radius,
                startAngle,
                endAngle
            );

            ctx.closePath();

            ctx.fillStyle = item.color;

            ctx.fill();

            ctx.strokeStyle = "#ffffff";

            ctx.lineWidth = 2;

            ctx.stroke();

            startAngle = endAngle;

        });


        // Total in center
        ctx.fillStyle = "#ffffff";

        ctx.font = "bold 25px Arial";

        ctx.textAlign = "center";

        ctx.textBaseline = "middle";

        ctx.fillText(
            total.toString(),
            centerX,
            centerY
        );

    }

}


// ============================================
// REGISTER DASHBOARD ACTION
// ============================================

registry.category("actions").add(
    "construction_dashboard",
    ConstructionDashboard
);
