/** @odoo-module **/

import {
    Component,
    onWillStart,
    onMounted,
    onPatched,
    onWillUnmount,
    useRef,
    useState,
} from "@odoo/owl";

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class ConstructionEVMChart extends Component {
    static template = "constructiondesigns.ConstructionEVMChart";

    setup() {
        this.orm = useService("orm");
        this.notification = useService("notification");
        this.chartRef = useRef("chartCanvas");

        this.state = useState({
            loading: true,
            error: "",
            projectName: "",
            projectBudget: 0,
            chartData: [],
            sv: 0,
            cv: 0,
            spi: 0,
            cpi: 0,
            latest: {
                pv: 0,
                ev: 0,
                ac: 0,
                sv: 0,
                cv: 0,
                spi: 0,
                cpi: 0,
            },
        });

        this.projectId = this.props.action?.params?.project_id;

        this.graphPoints = [];
        this.hoverPoint = null;
        this.resizeFrame = null;

        this.handleResize = () => {
            cancelAnimationFrame(this.resizeFrame);
            this.resizeFrame = requestAnimationFrame(() => {
                this.drawGraph();
            });
        };

        this.handleMouseMove = (event) => {
            const canvas = this.chartRef.el;
            if (!canvas || !this.graphPoints.length) {
                return;
            }

            const rect = canvas.getBoundingClientRect();
            const mouseX = event.clientX - rect.left;
            const mouseY = event.clientY - rect.top;

            let nearestPoint = null;
            let nearestDistance = Infinity;

            for (const point of this.graphPoints) {
                const distance = Math.hypot(
                    mouseX - point.x,
                    mouseY - point.y
                );

                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    nearestPoint = point;
                }
            }

            if (nearestPoint && nearestDistance <= 25) {
                this.hoverPoint = nearestPoint;
                canvas.style.cursor = "pointer";
            } else {
                this.hoverPoint = null;
                canvas.style.cursor = "default";
            }

            this.drawGraph();
        };

        this.handleMouseLeave = () => {
            this.hoverPoint = null;

            if (this.chartRef.el) {
                this.chartRef.el.style.cursor = "default";
            }

            this.drawGraph();
        };

        onWillStart(async () => {
            await this.loadChartData();
        });

        onMounted(() => {
            window.addEventListener("resize", this.handleResize);

            const canvas = this.chartRef.el;
            if (canvas) {
                canvas.addEventListener("mousemove", this.handleMouseMove);
                canvas.addEventListener("mouseleave", this.handleMouseLeave);
            }

            this.drawGraph();
        });

        onPatched(() => {
            if (!this.state.loading && this.state.chartData.length) {
                requestAnimationFrame(() => this.drawGraph());
            }
        });

        onWillUnmount(() => {
            window.removeEventListener("resize", this.handleResize);
            cancelAnimationFrame(this.resizeFrame);

            const canvas = this.chartRef.el;
            if (canvas) {
                canvas.removeEventListener("mousemove", this.handleMouseMove);
                canvas.removeEventListener("mouseleave", this.handleMouseLeave);
            }
        });
    }

    // =========================================================
    // LOAD CHART DATA
    // Expected Python result:
    // {
    //   project_name, project_budget,
    //   chart_data: [{date, budget, pv, ev, ac}, ...],
    //   latest: {pv, ev, ac, sv, cv, spi, cpi}
    // }
    // =========================================================

    async loadChartData() {
        this.state.loading = true;
        this.state.error = "";

        try {
            if (!this.projectId || this.projectId <= 0) {
                throw new Error(
                    "Project ID is missing. Open EVM Analysis from a project form."
                );
            }

            const result = await this.orm.call(
                "construction.project",
                "get_evm_chart_data",
                [this.projectId]
            );

            if (!result) {
                throw new Error("The Python method returned no chart data.");
            }

            this.state.projectName = result.project_name || "";
            this.state.projectBudget = this.toNumber(result.project_budget);

            this.state.chartData = (result.chart_data || [])
                .filter((row) => this.parseDate(row.date) !== null)
                .map((row) => ({
                    date: row.date,
                    timestamp: this.parseDate(row.date),
                    budget: this.toNullableNumber(row.budget),
                    pv: this.toNullableNumber(row.pv),
                    ev: this.toNullableNumber(row.ev),
                    ac: this.toNullableNumber(row.ac),
                }))
                .sort((a, b) => a.timestamp - b.timestamp);

            const latest = result.latest || {};

            this.state.latest = {
                pv: this.toNumber(latest.pv),
                ev: this.toNumber(latest.ev),
                ac: this.toNumber(latest.ac),
                sv: this.toNumber(latest.sv),
                cv: this.toNumber(latest.cv),
                spi: this.toNumber(latest.spi),
                cpi: this.toNumber(latest.cpi),
            };

            this.state.sv = this.state.latest.sv;
            this.state.cv = this.state.latest.cv;
            this.state.spi = this.state.latest.spi;
            this.state.cpi = this.state.latest.cpi;

            this.hoverPoint = null;
            this.graphPoints = [];

            if (!this.state.chartData.length) {
                this.state.error =
                    result.message ||
                    "No valid chart dates found. Check the WBS phase dates.";
            }
        } catch (error) {
            console.error("EVM chart loading failed:", error);

            this.state.error =
                error.message || "Unable to load EVM chart data.";

            this.notification.add(this.state.error, {
                type: "danger",
            });
        } finally {
            this.state.loading = false;
        }
    }

    async refreshChart() {
        this.hoverPoint = null;
        this.graphPoints = [];
        await this.loadChartData();
        this.drawGraph();
    }

    // =========================================================
    // HELPERS
    // =========================================================

    toNumber(value) {
        if (value === null || value === undefined || value === "") {
            return 0;
        }

        const number = Number(value);
        return Number.isFinite(number) ? number : 0;
    }

    toNullableNumber(value) {
        if (value === null || value === undefined || value === "") {
            return null;
        }

        const number = Number(value);
        return Number.isFinite(number) ? number : null;
    }

    parseDate(value) {
        if (!value) {
            return null;
        }

        const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
        if (!match) {
            return null;
        }

        const date = new Date(
            Number(match[1]),
            Number(match[2]) - 1,
            Number(match[3])
        );

        date.setHours(0, 0, 0, 0);
        return date.getTime();
    }

    formatDate(value) {
        const timestamp = this.parseDate(value);
        if (timestamp === null) {
            return value || "";
        }

        return new Date(timestamp).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
        });
    }

    formatKPI(value) {
        return this.toNumber(value).toFixed(2);
    }

    formatCurrency(value) {
        return new Intl.NumberFormat("en-IN", {
            style: "currency",
            currency: "INR",
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        }).format(this.toNumber(value));
    }

    formatNumber(value) {
        return new Intl.NumberFormat("en-IN", {
            style: "currency",
            currency: "INR",
            maximumFractionDigits: 0,
        }).format(this.toNumber(value));
    }

    shortCurrency(value) {
        const number = this.toNumber(value);

        if (number >= 10000000) {
            return `₹${(number / 10000000).toFixed(1)}Cr`;
        }
        if (number >= 100000) {
            return `₹${(number / 100000).toFixed(1)}L`;
        }
        if (number >= 1000) {
            return `₹${(number / 1000).toFixed(0)}K`;
        }

        return `₹${Math.round(number)}`;
    }

    getScheduleStatus() {
        if (this.state.spi > 1) return "Ahead of Schedule";
        if (this.state.spi < 1) return "Behind Schedule";
        return "On Schedule";
    }

    getCostStatus() {
        if (this.state.cpi > 1) return "Under Budget";
        if (this.state.cpi < 1) return "Over Budget";
        return "On Budget";
    }

    // =========================================================
    // DRAW THE GRAPH
    // =========================================================

    drawGraph() {
        const canvas = this.chartRef.el;

        if (!canvas || this.state.loading || !this.state.chartData.length) {
            return;
        }

        const rect = canvas.getBoundingClientRect();
        if (!rect.width || !rect.height) {
            return;
        }

        const width = rect.width;
        const height = rect.height;
        const ratio = window.devicePixelRatio || 1;

        canvas.width = Math.round(width * ratio);
        canvas.height = Math.round(height * ratio);

        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
        ctx.clearRect(0, 0, width, height);

        const margin = {
            top: 38,
            right: 25,
            bottom: 65,
            left: 85,
        };

        const graphWidth = width - margin.left - margin.right;
        const graphHeight = height - margin.top - margin.bottom;

        if (graphWidth <= 0 || graphHeight <= 0) return;

        const rows = this.state.chartData;

        const series = [
            { key: "budget", label: "Budget", color: "#64748b", width: 2.5 },
            { key: "pv", label: "Planned Value (PV)", color: "#2563eb", width: 2.8 },
            { key: "ev", label: "Earned Value (EV)", color: "#16a34a", width: 2.8 },
            { key: "ac", label: "Actual Cost (AC)", color: "#dc2626", width: 2.8 },
        ];

        const firstTimestamp = rows[0].timestamp;
        const lastTimestamp = rows[rows.length - 1].timestamp;
        const duration = lastTimestamp - firstTimestamp;

        // Use actual date distances for X positions.
        const xPosition = (timestamp) => {
            if (duration <= 0) {
                return margin.left + graphWidth / 2;
            }

            return margin.left +
                ((timestamp - firstTimestamp) / duration) * graphWidth;
        };

        // Calculate a non-negative Y-axis maximum.
        const values = [];

        for (const row of rows) {
            for (const item of series) {
                const value = row[item.key];
                if (value !== null && Number.isFinite(value)) {
                    values.push(value);
                }
            }
        }

        const maximum = Math.max(1, this.state.projectBudget, ...values);
        const yMax = maximum * 1.10;

        const yPosition = (value) => {
            return margin.top + graphHeight -
                (Math.max(0, value) / yMax) * graphHeight;
        };

        // =====================================================
        // GRID AND Y-AXIS
        // =====================================================

        ctx.font = "12px Arial";
        ctx.textAlign = "right";
        ctx.textBaseline = "middle";

        const gridCount = 5;

        for (let i = 0; i <= gridCount; i++) {
            const value = (yMax / gridCount) * i;
            const y = yPosition(value);

            ctx.beginPath();
            ctx.moveTo(margin.left, y);
            ctx.lineTo(width - margin.right, y);
            ctx.strokeStyle = "#e5e7eb";
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.fillStyle = "#374151";
            ctx.fillText(this.shortCurrency(value), margin.left - 10, y);
        }

        // =====================================================
        // AXES
        // =====================================================

        ctx.beginPath();
        ctx.moveTo(margin.left, margin.top);
        ctx.lineTo(margin.left, height - margin.bottom);
        ctx.lineTo(width - margin.right, height - margin.bottom);
        ctx.strokeStyle = "#6b7280";
        ctx.lineWidth = 1;
        ctx.stroke();

        // =====================================================
        // X-AXIS DATES
        // =====================================================

        ctx.fillStyle = "#374151";
        ctx.font = "11px Arial";
        ctx.textAlign = "center";
        ctx.textBaseline = "top";

        const labelCount = Math.min(6, rows.length);
        const displayedIndexes = new Set();

        for (let i = 0; i < labelCount; i++) {
            const index = labelCount === 1
                ? 0
                : Math.round((i / (labelCount - 1)) * (rows.length - 1));

            if (displayedIndexes.has(index)) continue;
            displayedIndexes.add(index);

            const label = this.formatDate(rows[index].date)
                .replace(/,\s*\d{4}$/, "");

            ctx.fillText(
                label,
                xPosition(rows[index].timestamp),
                height - margin.bottom + 12
            );
        }

        // =====================================================
        // CURRENT-DATE MARKER
        // Draw after grid/axes so it remains visible.
        // =====================================================

        const now = new Date();
        now.setHours(0, 0, 0, 0);
        const todayTimestamp = now.getTime();

        if (
            duration > 0 &&
            todayTimestamp >= firstTimestamp &&
            todayTimestamp <= lastTimestamp
        ) {
            const todayX = xPosition(todayTimestamp);

            ctx.save();
            ctx.beginPath();
            ctx.setLineDash([6, 4]);
            ctx.moveTo(todayX, margin.top);
            ctx.lineTo(todayX, height - margin.bottom);
            ctx.strokeStyle = "#ea580c";
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.setLineDash([]);

            ctx.fillStyle = "#ea580c";
            ctx.font = "bold 12px Arial";
            ctx.textAlign = "center";
            ctx.textBaseline = "bottom";
            ctx.fillText("Today", todayX, margin.top - 8);
            ctx.restore();
        }

        // =====================================================
        // SMOOTH CURVE FUNCTION
        // =====================================================

        const drawSmoothSegment = (points, item) => {
            if (!points.length) return;

            ctx.beginPath();
            ctx.strokeStyle = item.color;
            ctx.lineWidth = item.width;
            ctx.lineJoin = "round";
            ctx.lineCap = "round";
            ctx.moveTo(points[0].x, points[0].y);

            if (points.length === 1) {
                ctx.arc(points[0].x, points[0].y, 3, 0, Math.PI * 2);
                ctx.fillStyle = item.color;
                ctx.fill();
                return;
            }

            if (points.length === 2) {
                ctx.lineTo(points[1].x, points[1].y);
                ctx.stroke();
                return;
            }

            const tension = 0.25;

            for (let i = 0; i < points.length - 1; i++) {
                const p0 = points[Math.max(0, i - 1)];
                const p1 = points[i];
                const p2 = points[i + 1];
                const p3 = points[Math.min(points.length - 1, i + 2)];

                const cp1x = p1.x + (p2.x - p0.x) * tension;
                const cp1y = p1.y + (p2.y - p0.y) * tension;
                const cp2x = p2.x - (p3.x - p1.x) * tension;
                const cp2y = p2.y - (p3.y - p1.y) * tension;

                ctx.bezierCurveTo(
                    cp1x, cp1y,
                    cp2x, cp2y,
                    p2.x, p2.y
                );
            }

            ctx.stroke();
        };

        // =====================================================
        // DRAW BUDGET, PV, EV, AC
        // Null values break a series into separate segments.
        // =====================================================

        this.graphPoints = [];

        for (const item of series) {
            let segment = [];

            const finishSegment = () => {
                if (segment.length) {
                    drawSmoothSegment(segment, item);
                }
                segment = [];
            };

            for (const row of rows) {
                const value = row[item.key];

                if (value === null || value === undefined ||
                    !Number.isFinite(value)) {
                    finishSegment();
                    continue;
                }

                const point = {
                    x: xPosition(row.timestamp),
                    y: yPosition(value),
                    value,
                    date: row.date,
                    key: item.key,
                    label: item.label,
                };

                segment.push(point);
                this.graphPoints.push(point);
            }

            finishSegment();
        }

        // =====================================================
        // HOVER POINT AND TOOLTIP
        // =====================================================

        if (this.hoverPoint) {
            const point = this.hoverPoint;
            const item = series.find((s) => s.key === point.key);

            ctx.beginPath();
            ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
            ctx.fillStyle = "#ffffff";
            ctx.fill();
            ctx.strokeStyle = item ? item.color : "#111827";
            ctx.lineWidth = 3;
            ctx.stroke();

            const title = this.formatDate(point.date);
            const valueText = `${point.label}: ${this.formatNumber(point.value)}`;

            ctx.font = "12px Arial";
            const tooltipWidth = Math.max(
                ctx.measureText(title).width,
                ctx.measureText(valueText).width
            ) + 24;

            const tooltipHeight = 48;
            let tooltipX = point.x + 12;
            let tooltipY = point.y - tooltipHeight - 10;

            if (tooltipX + tooltipWidth > width - 5) {
                tooltipX = point.x - tooltipWidth - 12;
            }

            tooltipX = Math.max(5, tooltipX);

            if (tooltipY < 5) tooltipY = point.y + 12;
            if (tooltipY + tooltipHeight > height - 5) {
                tooltipY = height - tooltipHeight - 5;
            }

            ctx.fillStyle = "#111827";
            ctx.beginPath();

            if (typeof ctx.roundRect === "function") {
                ctx.roundRect(
                    tooltipX, tooltipY,
                    tooltipWidth, tooltipHeight, 5
                );
            } else {
                ctx.rect(
                    tooltipX, tooltipY,
                    tooltipWidth, tooltipHeight
                );
            }

            ctx.fill();

            ctx.textAlign = "left";
            ctx.textBaseline = "top";
            ctx.font = "11px Arial";
            ctx.fillStyle = "#d1d5db";
            ctx.fillText(title, tooltipX + 12, tooltipY + 7);

            ctx.font = "12px Arial";
            ctx.fillStyle = "#ffffff";
            ctx.fillText(valueText, tooltipX + 12, tooltipY + 25);
        }

        // =====================================================
        // LEGEND
        // =====================================================

        ctx.font = "12px Arial";
        ctx.textAlign = "left";
        ctx.textBaseline = "middle";

        const legendY = height - 18;
        const legendItemWidth = graphWidth / series.length;

        for (let i = 0; i < series.length; i++) {
            const item = series[i];
            const legendX = margin.left + i * legendItemWidth;

            ctx.beginPath();
            ctx.moveTo(legendX, legendY);
            ctx.lineTo(legendX + 18, legendY);
            ctx.strokeStyle = item.color;
            ctx.lineWidth = 3;
            ctx.stroke();

            ctx.fillStyle = "#374151";
            ctx.fillText(
                item.key.toUpperCase(),
                legendX + 24,
                legendY
            );
        }
    }
}

registry.category("actions").add(
    "construction_evm_simple_chart",
    ConstructionEVMChart
);