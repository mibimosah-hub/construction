/** @odoo-module **/
//
// console.log("Confirm button JavaScript file loaded");

document.addEventListener(
    "click",
    function (event) {
        console.log("Clicked element:", event.target);

        const button = event.target.closest("button.js_confirm_button");

        if (button) {
            console.log("Confirm button clicked");

            alert("Successfully Completed!");
        }
    },
    true
);