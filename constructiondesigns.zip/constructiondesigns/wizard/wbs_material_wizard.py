from odoo import fields, models


class WbsMaterialWizard(models.TransientModel):
    _name = 'wbs.material.wizard'
    _description = 'Select Material Wizard'

    phase_id = fields.Many2one(
        'wbs.phase',
        string='WBS Phase',
        required=True,
        readonly=True,
    )

    material_ids = fields.Many2many(
        'construction.stock',
        string='Materials',
    )

    def action_apply(self):
        self.ensure_one()

        if not self.phase_id:
            return {
                'type': 'ir.actions.act_window_close'
            }

        # IDs of materials already assigned to this phase
        existing_ids = self.phase_id.materials_ids.ids

        # Only selected materials that are not already assigned
        new_materials = self.material_ids.filtered(
            lambda material: material.id not in existing_ids
        )

        # Because materials_ids is One2many,
        # assign the phase through the inverse Many2one field.
        if new_materials:
            new_materials.write({
                'wbs_ids': self.phase_id.id,
            })

        return {
            'type': 'ir.actions.act_window_close'
        }
