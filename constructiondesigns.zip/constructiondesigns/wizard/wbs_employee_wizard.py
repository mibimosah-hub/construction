from odoo import fields, models, api


class WbsEmployeeWizard(models.TransientModel):
    _name = 'wbs.employee.wizard'
    _description = 'Select Employees'

    phase_id = fields.Many2one(
        'wbs.phase',
        string='WBS Phase',
        required=True,
        readonly=True,
    )

    department_id = fields.Many2one(
        'construction.department',
        string='Department',

    )

    designation_id = fields.Many2one(
        'designation.rec',
        string='Designation',

    )

    employee_ids = fields.Many2many(
        'construction.employee',
        string='Employees',

    )

    @api.onchange('department_id', 'designation_id')
    def _onchange_filter_employees(self):
        domain = [
            ('active', '=', True),
        ]

        if self.department_id:
            domain.append((
                'employee_department',
                '=',
                self.department_id.id
            ))

        if self.designation_id:
            domain.append((
                'employee_designation',
                '=',
                self.designation_id.id
            ))

        # Clear previously selected employees
        self.employee_ids = [(5, 0, 0)]

        return {
            'domain': {
                'employee_ids': domain
            }
        }

    # def action_add_employees(self):
    #     self.ensure_one()
    #
    #     if not self.phase_id:
    #         return {
    #             'type': 'ir.actions.act_window_close'
    #         }
    #
    #     self.employee_ids.write({
    #         'wbs_id': self.phase_id.id,
    #     })
    #
    #     return {
    #         'type': 'ir.actions.act_window_close'
    #     }

    def action_apply(self):
        """Takes selected checked rows and appends them to your main form grid"""
        self.ensure_one()

        new_lines = []
        for emp in self.employee_ids:
            # Check if this employee is already in the phase line-items to avoid duplicates
            existing = self.phase_id.employee_ids.filtered(lambda l: l.id == emp.id)
            if not existing:
                # Odoo relational link format: appends existing employee rows directly
                new_lines.append((4, emp.id))

        if new_lines:
            self.phase_id.write({'employee_ids': new_lines})

        return {'type': 'ir.actions.act_window_close'}