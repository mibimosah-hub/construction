from odoo import models, fields, api


class ConstructionTask(models.Model):
    _name = 'construction.task'
    _description = 'Construction Task'
    _rec_name = 'task_name'

    # -------------------------
    # BASIC INFORMATION
    # -------------------------

    project_id = fields.Many2one(
        'construction.project',
        string='Project',
        required=True,
        ondelete='cascade'
    )

    phase_id = fields.Many2one(
        'wbs.phase',
        string='Phase',
        required=True,
        ondelete='cascade'
    )

    floor_number = fields.Integer(
        string='Floor Number'
    )

    task_name = fields.Char(
        string='Task Name',
        required=True,
        size=100
    )

    description = fields.Text(
        string='Description'
    )

    # -------------------------
    # RESPONSIBILITY
    # -------------------------

    responsible_person = fields.Char(
        string='Responsible Person'
    )

    department = fields.Char(
        string='Department'
    )

    # -------------------------
    # PLANNING
    # -------------------------

    planned_start_date = fields.Date(
        string='Planned Start Date',
        required=True
    )

    planned_end_date = fields.Date(
        string='Planned End Date',
        required=True
    )

    duration = fields.Integer(
        string='Duration (Days)',
        store=True
    )

    priority = fields.Selection(
        [
            ('low', 'Low'),
            ('normal', 'Normal'),
            ('high', 'High'),
            ('urgent', 'Urgent'),
        ],
        string='Priority',
        default='normal'
    )

    # -------------------------
    # STATUS
    # -------------------------

    status = fields.Selection(
        [
            ('not_started', 'Not Started'),
            ('in_progress', 'In Progress'),
            ('completed', 'Completed'),
            ('on_hold', 'On Hold'),
            ('cancelled', 'Cancelled'),
        ],
        string='Status',
        default='not_started'
    )

    # -------------------------
    # PROGRESS
    # -------------------------

    completion_percent = fields.Float(
        string='% Completed',
        default=0.0
    )


