from odoo import models,fields

class ConstructionDepartment(models.Model):
    _name = 'construction.department'
    _description = 'Construction Department'
    _rec_name='department_name'

    designation_ids = fields.One2many(
        'designation.rec',
        'department_id',
        string="Designations"
    )
    department_id = fields.Char(string="Department ID")
    department_name = fields.Char(string="Department Name")
    department_description = fields.Char(string="Description")
    department_active = fields.Boolean(string="Active")


class ConstructionDesignation(models.Model):
    _name = 'designation.rec'
    _description = 'Construction Designation'
    _rec_name='designation_name'

    department_id = fields.Many2one(
        'construction.department',
        string="Department",
        required=True
    )
    designation_id = fields.Char(string="Designation ID")
    designation_name = fields.Char(string="Designation Name")
    designation_description = fields.Char(string="Description")
    designation_active = fields.Boolean(string="Active")