from odoo import fields, models

class Stages(models.Model):
    _name = 'construction.stages'
    _description = "Stages"
    _rec_name='stage_name'

    stage_id = fields.Char(string='Stage ID')
    stage_name = fields.Char(string='Stage Name')
    stage_description = fields.Char(string='Stage Description')
    stage_active = fields.Boolean(string='Stage Active')
