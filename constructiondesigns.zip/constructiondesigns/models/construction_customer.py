from odoo import fields, models,api
from odoo.exceptions import ValidationError
import re

class CustomerAdd(models.Model):
    _name = "customer.add"
    _description = "Customer Add"
    _rec_name='customer_name'

    customer_id=fields.Char(
        string="Customer ID",readonly=True,
    copy=False,)
    customer_name=fields.Char(
        string="Customer Name")
    customer_phone=fields.Char(
        string="Phone Number")
    customer_email=fields.Char(string="Email")
    customer_address=fields.Char(
        string="Address")
    customer_contact_person=fields.Char(string="Contact Person")
    customer_active=fields.Boolean(string="Active",default=True)
    state = fields.Selection(
        [
            ('draft', 'Draft'),
            ('confirmed', 'Confirmed'),
            ('cancelled', 'Cancelled'),
        ],
        string='Status',
        default='draft',
        copy=False
    )

    def action_draft(self):
        self.ensure_one()
        self.state = 'draft'

    def action_confirm(self):
        self.ensure_one()
        self.state = 'confirmed'

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Success',
                'message': 'Customer confirmed successfully!',
                'type': 'success',
                'sticky': False,
            }
        }

    def action_cancel(self):
        self.ensure_one()

        self.state = 'cancelled'


    # validations

    @api.constrains('customer_name')
    def check_customer_name(self):
        for record in self:

            if not record.customer_name:
                continue

            # Check special characters
            for character in record.customer_name:
                if not (
                        character.isalnum() or character == ' '
                ):
                    raise ValidationError(
                        'Customer Name cannot contain special characters.'
                    )

            # Check duplicate customer name
            duplicate = self.search([
                ('customer_name', '=', record.customer_name),
                ('id', '!=', record.id),
            ], limit=1)

            if duplicate:
                raise ValidationError(
                    'Customer Name already exists.'
                )

    @api.constrains('customer_phone')
    def check_customer_phone(self):
        for record in self:

            if not record.customer_phone:
                continue

            phone = record.customer_phone.strip()

            if not phone.isdigit():
                raise ValidationError(
                    'Customer Phone must contain only numbers.'
                )

            if len(phone) != 10:
                raise ValidationError(
                    'Customer Phone must contain 10 digits.'
                )

            duplicate = self.search([
                ('customer_phone', '=', phone),
                ('id', '!=', record.id),
            ], limit=1)

            if duplicate:
                raise ValidationError(
                    'Customer Phone already exists.'
                )

    @api.constrains('customer_email')
    def check_customer_email(self):
        for record in self:

            if not record.customer_email:
                continue

            email = record.customer_email.strip()

            # Email format validation
            pattern = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'

            if not re.match(pattern,email):
                raise ValidationError(
                    'Please enter a valid email address.'
                )

            # Check duplicate email
            duplicate = self.search([
                ('customer_email', '=', email),
                ('id', '!=', record.id),
            ], limit=1)

            if duplicate:
                raise ValidationError(
                    'Customer email already exists.'
                )

    @api.model_create_multi
    def create(self, vals_list):

        for vals in vals_list:

            if not vals.get('customer_id'):

                customer_name = (vals.get('customer_name') or '').strip()

                if customer_name:
                    customer_code = ''.join(
                        customer_name.split()
                    )[:3].upper()
                else:
                    customer_code = 'CUS'

                sequence_number = self.env['ir.sequence'].next_by_code(
                    'customer.add'
                )

                if not sequence_number:
                    raise ValidationError(
                        'Customer sequence is not configured.'
                    )

                year = fields.Date.today().year

                vals['customer_id'] = (
                    f"{customer_code}/{year}/{sequence_number}"
                )

        return super().create(vals_list)

