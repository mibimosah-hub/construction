from odoo import models, fields, api


class ConstructionEVMForecast(models.Model):
    _name = 'construction.evm.forecast'
    _description = 'Construction EVM Forecast'
    _rec_name = 'project_id'

    # =========================================
    # PROJECT
    # =========================================

    project_id = fields.Many2one(
        'construction.project',
        string='Project',
        required=True,
        ondelete='cascade'
    )

    # =========================================
    # RELATED PROJECT VALUES
    # =========================================

    project_name = fields.Char(
        string='Project Name',
        related='project_id.project_name',
        readonly=True
    )

    projectadd_id = fields.Char(
        string='Project ID',
        related='project_id.projectadd_id',
        readonly=True
    )

    total_project_budget = fields.Float(
        string='Total Project Budget',
        related='project_id.total_project_budget',
        readonly=True
    )

    project_total_ev = fields.Float(
        string='Total Earned Value',
        related='project_id.project_total_ev',
        readonly=True
    )

    project_total_ac = fields.Float(
        string='Total Actual Cost',
        related='project_id.project_total_ac',
        readonly=True
    )

    project_total_cpi = fields.Float(
        string='Cost Performance Index',
        related='project_id.project_total_cpi',
        readonly=True
    )

    # =========================================
    # FORECAST VALUES
    # =========================================

    estimate_at_completion = fields.Float(
        string='EAC (BAC\CPI)',
        compute='_compute_forecast'
    )

    estimate_to_complete = fields.Float(
        string='Estimate to Complete (ETC = EAC - AC)',
        compute='_compute_forecast'
    )

    variance_at_completion = fields.Float(
        string='Variance at Completion (VAC = BAC – EAC)',
        compute='_compute_forecast'
    )

    # =========================================
    # COMPUTE FORECAST
    # =========================================

    @api.depends(
        'project_id.total_project_budget',
        'project_id.project_total_ev',
        'project_id.project_total_ac',
        'project_id.project_total_cpi'
    )
    def _compute_forecast(self):

        for record in self:

            # BAC: Budget at Completion
            bac = record.total_project_budget or 0.0

            # AC: Actual Cost
            ac = record.project_total_ac or 0.0

            # CPI: Cost Performance Index
            cpi = record.project_total_cpi or 0.0

            # EAC: Estimate at Completion
            eac = bac / cpi if cpi > 0 else 0.0

            # ETC: Estimate to Complete
            etc = max(eac - ac, 0.0)

            # VAC: Variance at Completion
            vac = bac - eac

            record.estimate_at_completion = eac
            record.estimate_to_complete = etc
            record.variance_at_completion = vac