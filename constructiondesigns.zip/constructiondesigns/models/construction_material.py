from odoo import models, fields, api


class MaterialStock(models.Model):
    _name = 'construction.stock'
    _description = 'Material Stock'

    # Material details
    material_details_ids = fields.One2many(
        'material_details.rec',
        'material_id',
        string='Material Details'
    )

    wbs_ids = fields.Many2one(
        'wbs.phase',
        string='WBS Phase'
    )

    material_id = fields.Char(
        string='Material ID',
        required=True
    )

    material_name = fields.Char(
        string='Material Name',
        required=True
    )

    unit = fields.Selection([
        ('nos', 'Nos'),
        ('kg', 'Kg'),
        ('bags', 'Bags'),
        ('ton', 'Ton'),
        ('meter', 'Meter'),
        ('liter', 'Liter'),
    ], string='Unit', required=True)

    available_qty = fields.Float(
        string='Available Quantity'
    )

    # Total quantity from material detail records
    total_quantity = fields.Float(
        string='Total Quantity',
        compute='_compute_available_qty',
        store=False
    )

    minimum_qty = fields.Float(
        string='Minimum Quantity',
        default=10
    )

    # Total no of  the available stock
    stock_value = fields.Float(
        string='Stock Value',
        compute='_compute_stock_value',
        store=False
    )

    # Stock status
    status = fields.Selection([
        ('available', 'Available'),
        ('low', 'Low Stock'),
        ('out', 'Out of Stock'),
    ], string='Status', compute='_compute_status', store=True)

    # Unit amount calculation
    unit_no = fields.Float(
        string='Units'
    )

    unit_amount = fields.Float(
        string='Units Amount',
        compute='_compute_unit_value',
        store=False
    )

    all_materials_amount=fields.Float(string="Total Material Amount")
    no_of_material = fields.Integer(
        string="No. of Materials",
        compute="_compute_total_material",
        store=True
    )


    priority_materials=fields.Selection([
        ('low','Low'),
        ('high','High')],
        string="Priority Materials",default='high')
    low_stock_material=fields.Float(string="Low stock materials",compute='get_low_stock_count')

    # total material stock
    @api.depends('material_id')
    def _compute_total_material(self):
        for record in self:
            record.no_of_material = self.env['construction.stock'].search_count([])

    # low stock product
    @api.model
    def get_low_stock_count(self):
        return self.search_count([
            ('status', '=', 'low')
        ])

    # complete quantity
    @api.model
    def get_total_material_quantity(self):

        materials = self.search([])

        total = sum(materials.mapped('total_quantity'))

        return total
    # def action_view_materials(self):
    #     return {
    #         'type': 'ir.actions.act_window',
    #         'name': 'All Materials',
    #         'res_model': 'construction.stock',
    #         'view_mode': 'list,form',
    #         'target': 'current',
    #     }

    #full stock counts
    @api.model
    def get_all_material_amount(self):
        materials = self.search([])
        total = sum(materials.mapped('stock_value'))
        print(total)
        return total


    # Calculate total quantity
    @api.depends('material_details_ids.available_qty')
    def _compute_available_qty(self):
        for record in self:
            record.total_quantity = sum(
                record.material_details_ids.mapped('available_qty')
            )

    # Calculate stock value
    # Stock Value = Sum of (Available Quantity * Unit Cost)
    @api.depends(
        'material_details_ids.available_qty',
        'material_details_ids.unit_cost'
    )
    def _compute_stock_value(self):
        for record in self:
            record.stock_value = sum(
                detail.available_qty * detail.unit_cost
                for detail in record.material_details_ids
            )

    # Calculate amount for the specified number of units
    # Unit Amount = Units * Average Cost Per Unit
    @api.depends(
        'unit_no',
        'material_details_ids.available_qty',
        'material_details_ids.unit_cost'
    )
    def _compute_unit_value(self):
        for record in self:
            total_qty = sum(
                record.material_details_ids.mapped('available_qty')
            )

            total_value = sum(
                detail.available_qty * detail.unit_cost
                for detail in record.material_details_ids
            )

            if total_qty > 0:
                average_cost = total_value / total_qty
                record.unit_amount = record.unit_no * average_cost
            else:
                record.unit_amount = 0.0

    # Calculate stock status
    @api.depends(
        'material_details_ids.available_qty',
        'minimum_qty'
    )
    def _compute_status(self):
        for record in self:
            total_qty = sum(
                record.material_details_ids.mapped('available_qty')
            )

            if total_qty <= 0:
                record.status = 'out'

            elif total_qty <= record.minimum_qty:
                record.status = 'low'

            else:
                record.status = 'available'



class MaterialDetails(models.Model):
    _name = 'material_details.rec'
    _description = 'Material Details'
    _order = 'material_details_date desc, id desc'

    material_id = fields.Many2one(
        'construction.stock',
        string='Material',
        required=True,
        ondelete='cascade'
    )

    material_details_date = fields.Datetime(
        string='Date',
        default=fields.Datetime.now
    )

    available_qty = fields.Float(
        string='Available Quantity'
    )

    unit_cost = fields.Float(
        string='Unit Cost'
    )
    total_material_amount=fields.Float(string='Total',
    compute='_compute_total_material_amount',
    readonly=True,
    store=True)

    material_description = fields.Text(string='Description')
    material_documents = fields.Binary(
        string='Documents',
        attachment=True
    )

    @api.depends('available_qty','unit_cost')
    def _compute_total_material_amount(self):
        for record in self:
           record.total_material_amount = record.available_qty * record.unit_cost



class OtherService(models.Model):
    _name = 'other.service'
    _description = 'Other Service'

    wbs_service_id = fields.Many2one(
        'wbs.phase',
        string='WBS Phase'
    )

    other_service_name = fields.Selection([
        ('transport', 'Transport'),
        ('tools', 'Tool'),
        ('equipment', 'Equipment'),
        ('miscellaneous', 'Miscellaneous'),
        ('extraworkers', 'Extra Workers'),
    ], string='Service Name')

    other_service_description = fields.Text(
        string='Description'
    )

    other_service_cost = fields.Float(
        string='Cost'
    )

    other_service_unit = fields.Float(
        string='Unit',
        default=1.0
    )

    other_service_amount = fields.Float(
        string='Amount',
        compute='_compute_other_service_amount',
        store=False
    )

    other_service_documents = fields.Binary(
        string='Other Service Documents',
        attachment=True
    )

    # Calculate service amount
    @api.depends('other_service_unit', 'other_service_cost')
    def _compute_other_service_amount(self):
        for record in self:
            record.other_service_amount = (
                record.other_service_cost * record.other_service_unit
            )