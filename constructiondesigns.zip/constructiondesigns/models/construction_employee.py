from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError


class ConstructionEmployee(models.Model):
    _name = 'construction.employee'
    _description = 'Construction Employee'
    _rec_name = 'employee_name'

    # =====================================
    # EMPLOYEE DETAILS
    # =====================================

    wbs_id = fields.Many2one(
        'wbs.phase',
        string="WBS Phase"
    )

    employee_id = fields.Char(string="Employee Id")
    employee_name = fields.Char(string="Employee Name")
    employee_phone = fields.Char(string="Employee Phone")
    employee_email = fields.Char(string="Employee Email")
    employee_address = fields.Char(string="Employee Address")
    employee_location = fields.Char(string="Employee Location")

    employee_gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ], string="Gender")

    employee_department = fields.Many2one(
        'construction.department',
        string="Employee Department"
    )

    employee_designation = fields.Many2one(
        'designation.rec',
        string="Employee Designation"
    )

    employee_wage_type = fields.Selection([
        ('daily', 'Daily'),
        ('hourly', 'Hourly')
    ])

    employee_wage_amount = fields.Float(string="Wage Amount")
    employee_joining_date = fields.Datetime(string="Joining Date")
    employee_last_working_date = fields.Char(string="Last Working Date")
    employee_active = fields.Boolean(string="Active", default=True)

    # =====================================
    # LOGIN DETAILS
    # =====================================

    login_password = fields.Char(
        string="Password",
        copy=False
    )

    user_id = fields.Many2one(
        'res.users',
        string="Login User",
        readonly=True,
        copy=False
    )

    user_role = fields.Selection(
        [
            ('admin', 'Admin'),
            ('employee', 'Employee'),
        ],
        string="User Role",
        default='employee',
        required=True
    )

    # =====================================
    # EXISTING PAGE PERMISSIONS
    # =====================================

    access_dashboard = fields.Boolean(
        string="Dashboard Access",
        default=False
    )

    access_project = fields.Boolean(
        string="Project Access",
        default=False
    )

    access_project_type = fields.Boolean(
        string="Project Type Access",
        default=False
    )

    access_customer = fields.Boolean(
        string="Customer Access",
        default=False
    )

    # =====================================
    # DYNAMIC MENU PERMISSIONS
    # =====================================

    # =====================================
    # DYNAMIC MODEL PERMISSIONS
    # =====================================

    model_access_ids = fields.One2many(
        'construction.employee.model.access',
        'employee_id',
        string="Model Permissions"
    )

    employee_security_group_id = fields.Many2one(
        'res.groups',
        string="Employee Security Group",
        readonly=True,
        copy=False
    )

    # =====================================
    # VALIDATION
    # =====================================

    @api.constrains('employee_email')
    def _check_employee_email(self):
        for record in self:
            if record.employee_email:
                duplicate = self.search([
                    ('employee_email', '=', record.employee_email),
                    ('id', '!=', record.id)
                ], limit=1)

                if duplicate:
                    raise ValidationError(
                        _("Employee email already exists.")
                    )

    # =====================================
    # CREATE LOGIN
    # =====================================

    def action_create_login(self):

        for record in self:

            # Check existing login
            if record.user_id:
                raise UserError(
                    _("Login account already exists.")
                )

            # Validate employee details
            if not record.employee_name:
                raise UserError(
                    _("Please enter Employee Name.")
                )

            if not record.employee_email:
                raise UserError(
                    _("Please enter Employee Email.")
                )

            if not record.login_password:
                raise UserError(
                    _("Please enter Login Password.")
                )

            # Check duplicate Odoo login
            existing_user = self.env['res.users'].sudo().search([
                ('login', '=', record.employee_email)
            ], limit=1)

            if existing_user:
                raise UserError(
                    _("This email already has an Odoo login.")
                )

            # Internal User group
            internal_group = self.env.ref('base.group_user')

            # =================================
            # ADMIN LOGIN
            # =================================

            if record.user_role == 'admin':

                admin_group = self.env.ref(
                    'constructiondesigns.group_construction_admin'
                )

                selected_groups = internal_group | admin_group

            # =================================
            # EMPLOYEE LOGIN
            # =================================

            else:



                if not record.model_access_ids:
                    raise UserError(
                        _("Please select at least one model !!!!!.")
                    )

                # Create separate group for this employee
                employee_group = self.env['res.groups'].sudo().create({
                    'name': 'Construction Employee - %s' % (
                        record.employee_name
                    ),
                })

                record.sudo().write({
                    'employee_security_group_id': employee_group.id
                })

                selected_groups = internal_group | employee_group
#
            # =================================
            # CREATE ODOO USER
            # =================================

            user = self.env['res.users'].sudo().with_context(
                no_reset_password=True
            ).create({
                'name': record.employee_name,
                'login': record.employee_email,
                'email': record.employee_email,
                'password': record.login_password,
                'group_ids': [(6, 0, selected_groups.ids)],
            })

            # Link user to employee
            record.sudo().write({
                'user_id': user.id,
                'login_password': False,
            })

            # =================================
            # APPLY EMPLOYEE PERMISSIONS
            # =================================


        return True

    def _get_page_menu_mapping(self):
        return {
            'dashboard': 'constructiondesigns.menu_construction_dashboard',
            'project_add': 'constructiondesigns.menu_construction_project',
            'project_type': 'constructiondesigns.menu_project_type',
            'customer': 'constructiondesigns.menu_customer_add',
            # Add the remaining page menu XML IDs here
        }


# # =========================================
# # EMPLOYEE MODEL PERMISSION LINES
# # =========================================
#
class ConstructionEmployeeModelAccess(models.Model):

    _name = 'construction.employee.model.access'
    _description = 'Construction Employee Model Access'

    employee_id = fields.Many2one(
        'construction.employee',
        string="Employee",
        required=True,
        ondelete='cascade'
    )

    page_name = fields.Selection([
        ('dashboard', 'Dashboard'),
        ('project', 'Projects'),
        ('project_type', 'Project Types'),
        ('project_stages', 'Project Stages'),
        ('customer', 'Customers'),
        ('wbs', 'WBS'),
        ('tasks', 'Tasks'),
        ('milestones', 'Milestones'),
        ('schedule', 'Schedule'),
        ('material', 'Materials'),
        ('employee', 'Employees'),
        ('department', 'Departments'),
        ('cost', 'Costs'),
        ('progress', 'Progress'),
        ('evm', 'EVM'),
        ('reports', 'Reports'),
    ], string="Page Name", required=True)

    access_read = fields.Boolean(
        string="Read",
        default=True
    )

    access_write = fields.Boolean(
        string="Write",
        default=False
    )

    access_create = fields.Boolean(
        string="Create",
        default=False
    )

    access_delete = fields.Boolean(
        string="Delete",
        default=False
    )

    _sql_constraints = [
        (
            'unique_employee_model',
            'unique(employee_id, model_id)',
            'This model is already selected for this employee.'
        )
    ]