from odoo import fields, models

class ProjectType(models.Model):
    _name = 'project.type'
    _description = 'Project Type'
    _rec_name='project_type_name'

    project_type_id = fields.Char(string='Project Type Id')
    project_type_name = fields.Char(string='Project Type Name')
    project_active = fields.Boolean(string='Project Type Active', default=True)


