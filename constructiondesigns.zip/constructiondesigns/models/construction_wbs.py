from odoo import models, api, fields
from datetime import timedelta,date
from odoo.exceptions import ValidationError
class WbsPhase(models.Model):
    _name = 'wbs.phase'
    _description = 'WBS Phase'
    _rec_name = 'phase_name'

    phase_code = fields.Char(
        string='Phase ID',
        readonly=True,
        copy=False,
        index=True
    )

    employee_ids = fields.One2many(
        'construction.employee',
        'wbs_id',
        string="Employees"
    )
    other_service_id=fields.One2many('other.service','wbs_service_id',string="Other Service")
    materials_ids=fields.One2many('construction.stock','wbs_ids',string='Materials')
    employee_name=fields.Many2one('construction.employee',string='Employee Name')
    project_id = fields.Many2one(
        'construction.project',
        string='Project Name',
        required=True
    )

    description = fields.Char(
        string='Description',
        required=True,
        size=100
    )

    phase_name = fields.Char(
        string='Phase Name',
        required=True,
        size=100
    )

    phase_budget = fields.Float(
        string='Budget for Phase',
        required=True
    )
    phase_floor_no=fields.Integer(string='Floor No')
    planned_start_date = fields.Date(
        string='Planned Start Date',
        required=True
    )

    planned_end_date = fields.Date(
        string='Planned End Date',
        required=True
    )

    actual_start_date = fields.Date(
        string='Actual Start Date',
        required=True
    )

    actual_end_date = fields.Date(
        string='Actual End Date',

    )

    planned_value = fields.Float(
        string='Planned Value (PV)',
        compute='_compute_planned_value',
        store=True,
        aggregator='sum'
    )



    completion_percent = fields.Float(
        string='% Completed',
        default=0.0
    )

    status = fields.Selection(
        [
            ('not_started', 'Not Started'),
            ('in_progress', 'In Progress'),
            ('completed', 'Completed'),
        ],
        string='Status',
        compute='_compute_status',
        store=True
    )

    earned_value = fields.Float(
        string='Earned Value (EV)',
        compute='_compute_evm',
        store=True,
        aggregator='sum'
    )

    schedule_variance = fields.Float(
        string='Schedule Variance (SV)',
        compute='_compute_evm',
        store=True
    )

    cost_variance = fields.Float(
        string='Cost Variance (CV)',
        compute='_compute_evm',
        store=True,
        aggregator='sum'
    )

    spi = fields.Float(
        string='SPI',
        compute='_compute_evm',
        store=True
    )

    cpi = fields.Float(
        string='CPI',
        compute='_compute_evm',
        store=True
    )

    stages_id = fields.Many2one(
        'construction.stages',
        string='Stage'
    )

    allowed_stage_ids = fields.Many2many(
        'construction.stages',
        compute='_compute_allowed_stage_ids',
    )
    project_total_budget = fields.Float(
        string="Project Budget",
        related='project_id.total_project_budget',
        readonly=True
    )
    total_employee_cost=fields.Float(string="Total Employee Cost",default=0.0,compute='_compute_employee_wage_amount')
    total_material_cost=fields.Float(string='Total Material Cost',default=0.0,compute='_compute_unit_cost')
    total_extra_cost=fields.Float(string='Total Extra Cost',default=0.0,compute='_compute_other_service_amount')
    actual_cost = fields.Float(
        string='Actual Cost',
        compute='_compute_actual_cost',
        store=True

    )
    deadline_status=fields.Char(string="Deadline Status", compute='_compute_deadline_colour')
    deadline_overdue = fields.Boolean(
        string='Deadline Overdue',
        compute='_compute_deadline_colour',
        store=True
    )

    deadline_approaching = fields.Boolean(
        string='Deadline Approaching',
        compute='_compute_deadline_colour',
        store=True
    )

    deadline_safe = fields.Boolean(
        string='Deadline Safe',
        compute='_compute_deadline_colour',
        store=True
    )

    phase_completed = fields.Boolean(
        string='Phase Completed',
        compute='_compute_deadline_colour',
        store=True
    )

    @api.depends('planned_end_date', 'status')
    def _compute_deadline_colour(self):
        today = date.today()
        next_seven_days = today + timedelta(days=7)

        for phase in self:
            end_date = phase.planned_end_date

            phase.deadline_overdue = False
            phase.deadline_approaching = False
            phase.deadline_safe = False
            phase.phase_completed = phase.status == 'completed'

            # Completed phases always remain grey.
            if phase.phase_completed:
                continue

            if not end_date:
                continue

            if end_date < today:
                phase.deadline_overdue = True
                phase.deadline_status='Overdue'


            elif end_date <= next_seven_days:
                phase.deadline_approaching = True
                phase.deadline_status="Approaching"

            else:
                phase.deadline_safe = True
                phase.deadline_status="Safe"

    @api.model
    def get_deadline_chart_data(self):
        # 1. Read the counts directly using ORM search groups for optimal speed
        overdue_count = self.search_count([('deadline_overdue', '=', True), ('status', '!=', 'completed')])
        approaching_count = self.search_count([('deadline_approaching', '=', True), ('status', '!=', 'completed')])
        safe_count = self.search_count([('deadline_safe', '=', True), ('status', '!=', 'completed')])

        # 2. Return the structured dictionary payload back to your dashboard chart widget
        return [
            {'label': 'Overdue', 'count': overdue_count},
            {'label': 'Approaching', 'count': approaching_count},
            {'label': 'Safe', 'count': safe_count},
        ]

    @api.depends('employee_ids.employee_wage_amount')
    def _compute_employee_wage_amount(self):
        for rec in self:
            rec.total_employee_cost = sum(rec.employee_ids.mapped('employee_wage_amount'))

    @api.depends('materials_ids.unit_amount')
    def _compute_unit_cost(self):
        for rec in self:
            rec.total_material_cost = sum(rec.materials_ids.mapped('unit_amount'))

    @api.depends('other_service_id.other_service_amount')
    def _compute_other_service_amount(self):
        for rec in self:
            rec.total_extra_cost = sum(rec.other_service_id.mapped('other_service_amount'))

    @api.depends(
        'employee_ids.employee_wage_amount',
        'materials_ids.unit_amount',
        'other_service_id.other_service_amount'
    )
    def _compute_actual_cost(self):
        for rec in self:
            rec.actual_cost = (
                sum(rec.employee_ids.mapped('employee_wage_amount')) +
                sum(rec.materials_ids.mapped('unit_amount')) +
                sum(rec.other_service_id.mapped('other_service_amount'))
            )


    @api.depends('project_id', 'project_id.stage_ids')
    def _compute_allowed_stage_ids(self):
        for rec in self:
            if rec.project_id:
                rec.allowed_stage_ids = rec.project_id.stage_ids
            else:
                rec.allowed_stage_ids = False

    @api.onchange('project_id')
    def _onchange_project_id(self):
        self.stages_id = False

    @api.depends('phase_budget')
    def _compute_planned_value(self):
        for r in self:
            r.planned_value = r.phase_budget

    @api.depends('completion_percent')
    def _compute_status(self):
        for r in self:
            if r.completion_percent == 0:
                r.status = 'not_started'
            elif r.completion_percent < 100:
                r.status = 'in_progress'
            else:
                r.status = 'completed'

    @api.depends(
        'phase_budget',
        'planned_value',
        'actual_cost',
        'completion_percent'
    )
    def _compute_evm(self):
        for r in self:

            r.earned_value = (
                r.completion_percent / 100
            ) * r.phase_budget

            r.schedule_variance = (
                r.earned_value - r.planned_value
            )

            r.cost_variance = (
                r.earned_value - r.actual_cost
            )

            r.spi = (
                r.earned_value / r.planned_value
                if r.planned_value
                else 0.0
            )

            r.cpi = (
                r.earned_value / r.actual_cost
                if r.actual_cost
                else 0.0
            )


    def action_open_employee_wizard(self):
        self.ensure_one()

        return {
            'type': 'ir.actions.act_window',
            'name': 'Select Employee',
            'res_model': 'wbs.employee.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref(
                'constructiondesigns.employee_selection_wizard_form'
            ).id,
            'target': 'new',
            'context': {
                'default_phase_id': self.id,
            },
        }

    def action_open_material_wizard(self):
        self.ensure_one()

        return {
            'type': 'ir.actions.act_window',
            'name': 'Select Materials',
            'res_model': 'wbs.material.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref(
                'constructiondesigns.materials_selection_wizard_form'
            ).id,
            'target': 'new',
            'context': {
                'default_phase_id': self.id,
            },
        }
    #sequences
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:

            print("CREATE VALUES:", vals)

            sequence_number = self.env['ir.sequence'].next_by_code(
                'wbs.phase'
            )

            print("SEQUENCE RESULT:", sequence_number)

            if not sequence_number:
                raise ValidationError(
                    'WBS Phase sequence is not configured.'
                )

            year = fields.Date.today().year

            vals['phase_code'] = f'PHASE/{year}/{sequence_number}'

            print("FINAL PHASE CODE:", vals['phase_code'])

        return super().create(vals_list)


