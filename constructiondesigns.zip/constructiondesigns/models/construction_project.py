from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date,timedelta

class ConstructionProject(models.Model):
    _name = 'construction.project'
    _description = 'Construction Project'
    _rec_name = 'project_name'

    # =========================================================
    # BASIC PROJECT INFORMATION
    # =========================================================

    customer_id = fields.Many2one(
        'customer.add',
        string='Customer Name',
        required=True
    )
    evm_forecast_ids = fields.One2many(
        'construction.evm.forecast',
        'project_id',
        string='EVM Forecasts'
    )
    projectadd_id = fields.Char(
        string='Project Id',
        readonly=True,
        copy=False,
    )

    project_types_id = fields.Many2one(
        'project.type',
        string='Project Types'
    )

    project_name = fields.Char(
        string='Project Name',
        size=50,
        required=True
    )

    project_description = fields.Char(
        string='Project Description',
        size=100,
        required=True
    )

    planned_start_date = fields.Date(
        string='Planned Start Date',
        required=True
    )

    planned_end_date = fields.Date(
        string='Planned End Date',
        required=True
    )

    actual_start_date = fields.Date(
        string='Actual Start Date'
    )

    actual_end_date = fields.Date(
        string='Actual End Date'
    )

    total_project_budget = fields.Float(
        string='Total Project Budget',
        required=True
    )

    # =========================================================
    # PROJECT STAGES
    # =========================================================

    stage_ids = fields.Many2many(
        'construction.stages',
        string='Project Stages'
    )

    # =========================================================
    # PROJECT PHASES
    # =========================================================

    phase_ids = fields.One2many(
        'wbs.phase',
        'project_id',
        string='WBS Phases'
    )

    # =========================================================
    # OTHER PROJECT INFORMATION
    # =========================================================

    project_active = fields.Boolean(
        string='Project Active',
        default=True
    )

    project_location = fields.Char(
        string='Location'
    )

    project_address = fields.Char(
        string='Address'
    )

    project_incharge = fields.Char(
        string='Project Incharge'
    )

    project_contact_person = fields.Char(
        string='Contact Person'
    )

    project_email = fields.Char(
        string='Contact Email'
    )

    project_phone = fields.Char(
        string='Contact Phone'
    )

    # =========================================================
    # PROJECT STATUS
    # =========================================================

    state = fields.Selection(
        [
            ('draft', 'Draft'),
            ('confirmed', 'Confirmed'),
            ('cancelled', 'Cancelled'),
        ],
        string='Status',
        default='draft',
        copy=False
    )

    # =========================================================
    # PROJECT EVM
    # =========================================================

    project_total_pv = fields.Float(
        string='Project Total PV',
        compute='_compute_project_evm',
        store=False,
    )

    project_total_ev = fields.Float(
        string='Project Total EV',
        compute='_compute_project_evm',
        store=False,
    )

    project_total_ac = fields.Float(
        string='Project Total AC',
        compute='_compute_project_evm',
        store=False,
    )

    project_total_sv = fields.Float(
        string='Project Total SV',
        compute='_compute_project_evm',
        store=False,
    )

    project_total_cv = fields.Float(
        string='Project Total CV',
        compute='_compute_project_evm',
        store=False,
    )

    project_total_spi = fields.Float(
        string='Project SPI',
        compute='_compute_project_evm',
        store=False,
    )

    project_total_cpi = fields.Float(
        string='Project CPI',
        compute='_compute_project_evm',
        store=False)

    project_status = fields.Selection([
        ('in_progress', 'In Progress'),
        ('on_hold', 'On Hold'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ], string='Project Status', default='in_progress', required=True)

    project_days_differnces=fields.Float(
            string="No of Days",
            compute="_compute_project_days",
            store=True
        )

    project_weeks = fields.Float(
        string='No of Weeks',
        compute='_compute_project_weeks',
        store=True
    )

    @api.depends('project_days_differnces')
    def _compute_project_weeks(self):
        for record in self:
            if record.project_days_differnces:
                record.project_weeks = record.project_days_differnces / 7
            else:
                record.project_weeks = 0.0

    @ api.depends('planned_start_date', 'planned_end_date')
    def _compute_project_days(self):
        for record in self:
            if record.planned_start_date and record.planned_end_date:
                record.project_days_differnces = (
                        record.planned_end_date - record.planned_start_date
                ).days
            else:
                record.project_days_differnces = 0.0

    # =========================================================
    # PROJECT EVM COMPUTATION
    # =========================================================

    @api.depends(
        'phase_ids.planned_value',
        'phase_ids.earned_value',
        'phase_ids.actual_cost',
    )
    def _compute_project_evm(self):

        for project in self:

            phases = project.phase_ids

            # -------------------------------------------------
            # TOTAL PV
            # -------------------------------------------------

            total_pv = sum(
                phases.mapped('planned_value')
            )

            # -------------------------------------------------
            # TOTAL EV
            # -------------------------------------------------

            total_ev = sum(
                phases.mapped('earned_value')
            )

            # -------------------------------------------------
            # TOTAL AC
            # -------------------------------------------------

            total_ac = sum(
                phases.mapped('actual_cost')
            )

            # -------------------------------------------------
            # SET TOTALS
            # -------------------------------------------------

            project.project_total_pv = total_pv
            project.project_total_ev = total_ev
            project.project_total_ac = total_ac

            # -------------------------------------------------
            # SV = EV - PV
            # -------------------------------------------------

            project.project_total_sv = (
                total_ev - total_pv
            )

            # -------------------------------------------------
            # CV = EV - AC
            # -------------------------------------------------

            project.project_total_cv = (
                total_ev - total_ac
            )

            # -------------------------------------------------
            # SPI = EV / PV
            # -------------------------------------------------

            project.project_total_spi = (
                total_ev / total_pv
                if total_pv
                else 0.0
            )

            # -------------------------------------------------
            # CPI = EV / AC
            # -------------------------------------------------

            project.project_total_cpi = (
                total_ev / total_ac
                if total_ac
                else 0.0
            )

    # =========================================================
    # PROJECT STATE ACTIONS
    # =========================================================

    def action_draft(self):
        self.ensure_one()

        self.state = 'draft'

    def action_confirm(self):
        self.ensure_one()

        self.state = 'confirmed'

        # return {
        #     'type': 'ir.actions.client',
        #     'tag': 'display_notification',
        #     'params': {
        #         'title': 'Success',
        #         'message': 'Project Created successfully!',
        #         'type': 'success',
        #         'sticky': False,
        #     }
        # }

    def action_cancel(self):
        self.ensure_one()

        self.state = 'cancelled'

    def action_back(self):
        return self.env.ref(
            'constructiondesigns.action_construction_project'
        ).read()[0]

    # =========================================================
    # CREATE PROJECT ID
    # =========================================================

    @api.model_create_multi
    def create(self, vals_list):

        for vals in vals_list:

            if not vals.get('projectadd_id'):

                # -------------------------------------------------
                # PROJECT NAME CODE
                # -------------------------------------------------

                project_name = (
                    vals.get('project_name') or ''
                ).strip()

                if project_name:

                    project_code = ''.join(
                        project_name.split()
                    )[:3].upper()

                else:

                    project_code = 'PRO'

                # -------------------------------------------------
                # PROJECT TYPE CODE
                # -------------------------------------------------

                project_type_id = vals.get(
                    'project_types_id'
                )

                if project_type_id:

                    project_type = self.env[
                        'project.type'
                    ].browse(
                        project_type_id
                    )

                    if project_type.exists():

                        project_type_name = (
                            project_type.project_type_name
                            or ''
                        )

                        project_type_code = ''.join(
                            project_type_name.split()
                        )[:3].upper()

                    else:

                        project_type_code = 'TYPE'

                else:

                    project_type_code = 'TYPE'

                # -------------------------------------------------
                # CUSTOMER CODE
                # -------------------------------------------------

                customer_id = vals.get(
                    'customer_id'
                )

                if customer_id:

                    customer = self.env[
                        'customer.add'
                    ].browse(
                        customer_id
                    )

                    if customer.exists():

                        customer_name = (
                            customer.customer_name
                            or ''
                        )

                        customer_code = ''.join(
                            customer_name.split()
                        )[:3].upper()

                    else:

                        customer_code = 'CUS'

                else:

                    customer_code = 'CUS'

                # -------------------------------------------------
                # SEQUENCE
                # -------------------------------------------------

                sequence_number = self.env[
                    'ir.sequence'
                ].next_by_code(
                    'construction.project'
                )

                if not sequence_number:

                    raise ValidationError(
                        'Project sequence is not configured.'
                    )

                # -------------------------------------------------
                # YEAR
                # -------------------------------------------------

                year = fields.Date.today().year

                # -------------------------------------------------
                # PROJECT ID
                # -------------------------------------------------

                vals['projectadd_id'] = (
                    f"PRJ/{project_code}/"
                    f"{project_type_code}/"
                    f"{customer_code}/"
                    f"{year}/"
                    f"{sequence_number}"
                )

        return super().create(vals_list)

    # =========================================================
    # PROJECT NAME VALIDATION
    # =========================================================

    @api.constrains('project_name')
    def check_project_name(self):

        for record in self:

            if not record.project_name:
                continue

            # -------------------------------------------------
            # SPECIAL CHARACTER CHECK
            # -------------------------------------------------

            for character in record.project_name:

                if not (
                    character.isalnum()
                    or character == ' '
                ):

                    raise ValidationError(
                        'Project Name cannot contain '
                        'special characters.'
                    )

            # -------------------------------------------------
            # DUPLICATE PROJECT NAME CHECK
            # -------------------------------------------------

            duplicate = self.search(
                [
                    ('project_name', '=', record.project_name),
                    ('id', '!=', record.id),
                ],
                limit=1
            )

            if duplicate:

                raise ValidationError(
                    'Project Name already exists.'
                )

    # =========================================================
    # PLANNED DATE VALIDATION
    # =========================================================

    @api.constrains(
        'planned_start_date',
        'planned_end_date'
    )
    def _check_planned_end_date(self):

        for record in self:

            if (
                not record.planned_start_date
                or not record.planned_end_date
            ):
                continue

            today = date.today()

            minimum_date = today.replace(
                year=today.year - 25
            )

            # -------------------------------------------------
            # PLANNED START DATE
            # -------------------------------------------------

            if record.planned_start_date < minimum_date:

                raise ValidationError(
                    'Planned Start Date cannot be more '
                    'than 25 years before the current date.'
                )

            # -------------------------------------------------
            # PLANNED END DATE
            # -------------------------------------------------

            if (
                record.planned_end_date
                < record.planned_start_date
            ):

                raise ValidationError(
                    'Planned End Date must be greater '
                    'than Planned Start Date.'
                )

            # -------------------------------------------------
            # PLANNED END DATE RANGE
            # -------------------------------------------------

            if record.planned_end_date < minimum_date:

                raise ValidationError(
                    'Planned End Date cannot be more '
                    'than 25 years before the current date.'
                )

    # =========================================================
    # ACTUAL START DATE VALIDATION
    # =========================================================

    @api.constrains(
        'actual_start_date',
        'planned_start_date'
    )
    def _check_actual_start_date(self):

        for record in self:

            if (
                record.actual_start_date
                and record.planned_start_date
            ):

                if (
                    record.actual_start_date
                    < record.planned_start_date
                ):

                    raise ValidationError(
                        'Actual Start Date must be greater '
                        'than or equal to Planned Start Date.'
                    )


    # =========================================================
    # EVM CHART DATA
    # =========================================================

    @api.model
    def get_evm_chart_data(self, project_id):

        project = self.browse(project_id).exists()

        if not project:
            return {
                "project_name": "",
                "chart_data": [],
                "latest": self._empty_evm_values(),
            }

        today = fields.Date.context_today(self)

        # -----------------------------------------------------
        # SECTION 1: FETCH WBS PHASE DATA
        # -----------------------------------------------------

        phase_data = []

        all_start_dates = []
        all_planned_end_dates = []
        all_actual_end_dates = []

        total_ev = 0.0
        total_ac = 0.0

        for phase in project.phase_ids:

            planned_start = (
                fields.Date.to_date(phase.planned_start_date)
                if phase.planned_start_date
                else None
            )

            planned_end = (
                fields.Date.to_date(phase.planned_end_date)
                if phase.planned_end_date
                else None
            )

            actual_start = (
                fields.Date.to_date(phase.actual_start_date)
                if phase.actual_start_date
                else None
            )

            actual_end = (
                fields.Date.to_date(phase.actual_end_date)
                if phase.actual_end_date
                else None
            )

            # Phase budget
            budget = float(phase.phase_budget or 0.0)

            # Planned value
            planned_value = float(
                phase.planned_value or budget
            )

            # Earned value
            earned_value = (
                    budget
                    * float(phase.completion_percent or 0.0)
                    / 100.0
            )

            # Actual cost
            actual_cost = float(phase.actual_cost or 0.0)

            total_ev += earned_value
            total_ac += actual_cost

            # Collect dates for the chart
            if planned_start:
                all_start_dates.append(planned_start)

            if actual_start:
                all_start_dates.append(actual_start)

            if planned_end:
                all_planned_end_dates.append(planned_end)

            if actual_end:
                all_actual_end_dates.append(actual_end)

            phase_data.append({
                "phase_name": phase.phase_name or "",

                "planned_start": planned_start,
                "planned_end": planned_end,

                "actual_start": actual_start,
                "actual_end": actual_end,

                "budget": budget,
                "planned_value": planned_value,
                "earned_value": earned_value,
                "actual_cost": actual_cost,
            })

        # -----------------------------------------------------
        # SECTION 2: DETERMINE CHART START AND END DATES
        # -----------------------------------------------------

        if not phase_data or not all_start_dates:
            return {
                "project_name": project.project_name or "",
                "chart_data": [],
                "latest": self._empty_evm_values(),
            }

        chart_start = min(all_start_dates)

        # If the project has an actual end date, stop the
        # PV / EV / AC lines at that date.
        #
        # Otherwise, stop them at today's date.
        if project.actual_end_date:
            actual_stop_date = fields.Date.to_date(
                project.actual_end_date
            )
        else:
            actual_stop_date = today

        # Budget line should extend to the later of:
        # 1. Planned project end
        # 2. Actual project end / today's date
        planned_project_end = (
            fields.Date.to_date(project.planned_end_date)
            if project.planned_end_date
            else today
        )

        chart_end = max(
            planned_project_end,
            actual_stop_date,
        )

        if chart_end < chart_start:
            chart_end = chart_start

        # Safety limit: maximum chart period of 10 years
        if (chart_end - chart_start).days > 3650:
            chart_end = chart_start + timedelta(days=3650)

            actual_stop_date = min(
                actual_stop_date,
                chart_end,
            )

        # -----------------------------------------------------
        # SECTION 3: CALCULATE LATEST EVM VALUES
        # -----------------------------------------------------

        # Latest date for project performance calculations
        latest_date = min(today, actual_stop_date)

        pv_latest = self._calculate_planned_value(
            phase_data,
            latest_date,
        )

        ev_latest = self._calculate_actual_timeline_value(
            phase_data,
            latest_date,
            "earned_value",
            today,
        )

        ac_latest = self._calculate_actual_timeline_value(
            phase_data,
            latest_date,
            "actual_cost",
            today,
        )

        sv = ev_latest - pv_latest
        cv = ev_latest - ac_latest

        spi = (
            ev_latest / pv_latest
            if pv_latest
            else 0.0
        )

        cpi = (
            ev_latest / ac_latest
            if ac_latest
            else 0.0
        )

        latest = {
            "pv": round(pv_latest, 2),
            "ev": round(ev_latest, 2),
            "ac": round(ac_latest, 2),

            "sv": round(sv, 2),
            "cv": round(cv, 2),

            "spi": round(spi, 2),
            "cpi": round(cpi, 2),
        }

        # -----------------------------------------------------
        # SECTION 4: BUILD DAILY CHART DATA
        # -----------------------------------------------------

        chart_data = []

        current_date = chart_start

        project_budget = float(
            project.total_project_budget or 0.0
        )

        while current_date <= chart_end:

            # Planned Value from WBS planned dates
            pv = self._calculate_planned_value(
                phase_data,
                current_date,
            )

            if current_date <= actual_stop_date:

                # Estimated cumulative Earned Value
                ev = self._calculate_actual_timeline_value(
                    phase_data,
                    current_date,
                    "earned_value",
                    today,
                )

                # Estimated cumulative Actual Cost
                ac = self._calculate_actual_timeline_value(
                    phase_data,
                    current_date,
                    "actual_cost",
                    today,
                )

                pv_value = round(pv, 2)
                ev_value = round(ev, 2)
                ac_value = round(ac, 2)

            else:
                # Stop the three EVM lines.
                #
                # Chart.js displays these None values as gaps.
                pv_value = None
                ev_value = None
                ac_value = None

            chart_data.append({
                "date": current_date.isoformat(),

                # Budget continues through chart_end
                "budget": round(project_budget, 2),

                "pv": pv_value,
                "ev": ev_value,
                "ac": ac_value,
            })

            current_date += timedelta(days=1)

        # -----------------------------------------------------
        # SECTION 5: RETURN DATA TO OWL / JAVASCRIPT
        # -----------------------------------------------------

        return {
            "project_name": project.project_name or "",
            "chart_data": chart_data,
            "latest": latest,
        }

    # =========================================================
    # EMPTY EVM VALUES
    # =========================================================

    @api.model
    def _empty_evm_values(self):

        return {
            "pv": 0.0,
            "ev": 0.0,
            "ac": 0.0,

            "sv": 0.0,
            "cv": 0.0,

            "spi": 0.0,
            "cpi": 0.0,
        }

    # =========================================================
    # CALCULATE PLANNED VALUE
    # =========================================================

    @api.model
    def _calculate_planned_value(
            self,
            phase_data,
            target_date,
    ):

        total_pv = 0.0

        for phase in phase_data:

            planned_start = phase["planned_start"]
            planned_end = phase["planned_end"]

            planned_value = phase["planned_value"]

            # Cannot calculate PV without planned dates
            if not planned_start or not planned_end:
                continue

            # Before the phase starts
            if target_date < planned_start:
                continue

            # Handle a phase whose start and end dates are equal
            if planned_end <= planned_start:

                if target_date >= planned_end:
                    total_pv += planned_value

                continue

            # Phase is completed according to its planned dates
            if target_date >= planned_end:

                total_pv += planned_value

            else:

                # Calculate the elapsed portion of the phase
                total_days = (
                        planned_end - planned_start
                ).days

                elapsed_days = (
                        target_date - planned_start
                ).days

                if total_days > 0:
                    progress = (
                            elapsed_days / total_days
                    )

                    progress = max(
                        0.0,
                        min(progress, 1.0),
                    )

                    total_pv += (
                            planned_value * progress
                    )

        return total_pv

    # =========================================================
    # CALCULATE EARNED VALUE / ACTUAL COST TIMELINE
    # =========================================================

    @api.model
    def _calculate_actual_timeline_value(
            self,
            phase_data,
            target_date,
            value_key,
            today,
    ):

        total_value = 0.0

        for phase in phase_data:

            # Prefer actual start date.
            # If unavailable, use planned start date.
            start_date = (
                    phase["actual_start"]
                    or phase["planned_start"]
            )

            if not start_date:
                continue

            # Prefer actual end date.
            # If unavailable, use today's date.
            end_date = (
                    phase["actual_end"]
                    or today
            )

            phase_value = float(
                phase.get(value_key, 0.0) or 0.0
            )

            # Before the phase starts
            if target_date < start_date:
                continue

            # Phase start and end are the same date
            if end_date <= start_date:

                if target_date >= end_date:
                    total_value += phase_value

                continue

            # After the phase ends, include its full value
            if target_date >= end_date:

                total_value += phase_value

            else:

                # Estimate cumulative progress over time
                total_days = (
                        end_date - start_date
                ).days

                elapsed_days = (
                        target_date - start_date
                ).days

                progress = (
                    elapsed_days / total_days
                    if total_days > 0
                    else 0.0
                )

                progress = max(
                    0.0,
                    min(progress, 1.0),
                )

                total_value += (
                        phase_value * progress
                )

        return total_value

    # =========================================================
    # OPEN EVM CHART
    # =========================================================

    def action_open_evm_chart(self):
        self.ensure_one()

        return {
            "type": "ir.actions.client",
            "name": "EVM Analysis",
            "tag": "construction_evm_simple_chart",
            "params": {
                "project_id": self.id,
            },
        }

    # =========================================
    # EVM FORECAST
    # =========================================

    evm_forecast_id = fields.Many2one(
        'construction.evm.forecast',
        string='Selected EVM Forecast',
        compute='_compute_evm_forecast',
        readonly=True,
        store=True
    )

    estimate_at_completion = fields.Float(
        string='Estimate at Completion (EAC)',
        related='evm_forecast_id.estimate_at_completion',
        readonly=True,
        store=True
    )

    estimate_to_complete = fields.Float(
        string='Estimate to Complete (ETC)',
        related='evm_forecast_id.estimate_to_complete',
        readonly=True,
        store=True
    )

    variance_at_completion = fields.Float(
        string='Variance at Completion (VAC)',
        related='evm_forecast_id.variance_at_completion',
        readonly=True,
        store=True
    )

    @api.depends('project_name')
    def _compute_evm_forecast(self):
        for project in self:
            forecast = self.env['construction.evm.forecast'].search(
                [('project_id', '=', project.id)],
                limit=1
            )
            project.evm_forecast_id = forecast