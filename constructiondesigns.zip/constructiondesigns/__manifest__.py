{
    'name': 'Construction Design',
    'version': '19.0.1.0.0',
    'category': 'Project',
    'summary': 'Construction Project Management',
    'author': 'AQUES',
    'license': 'LGPL-3',

    'depends': [
        'base',
        'project',
    ],

    'data': [

        # 2. Model Access Rights
        'security/ir.model.access.csv',

        # 3. Sequences
        'data/phase_sequence.xml',
        'data/customer_sequences.xml',
        'data/project_sequence.xml',

        # 4. Login Templates
        'views/login_templates.xml',

        # 5. Main Views and Menus
        'views/construction_project_views.xml',
        'views/construction_dashboard.xml',
        'views/wbs_phase_views.xml',
        'views/evm_report.xml',
        'views/project_type_views.xml',
        'views/construction_task_view.xml',
        'views/customer_add_views.xml',
        'views/construction_stage_views.xml',
        'views/construction_department_view.xml',
        'views/construction_employee_views.xml',
        'views/construction_material_view.xml',
        'views/evm_chart_action.xml',
        'views/construction_deadline.xml',
        'views/evm_forecast_views.xml',

        # 6. Wizards
        'wizard/wbs_employee_wizard_views.xml',
        'wizard/wbs_materials_wizard_views.xml',

    ],

    'assets': {
        'web.assets_backend': [
            'constructiondesigns/static/src/js/button.js',
            'constructiondesigns/static/src/js/evm_chart.js',
            'constructiondesigns/static/src/xml/evm_chart_template.xml',
            'constructiondesigns/static/src/css/evm_chart.css',
            'constructiondesigns/static/src/css/construction_deadline.css',
            'constructiondesigns/static/src/js/dashboard.js',
            'constructiondesigns/static/src/xml/construction_dashboard.xml',
        ],
    },

    'installable': True,
    'application': True,
}